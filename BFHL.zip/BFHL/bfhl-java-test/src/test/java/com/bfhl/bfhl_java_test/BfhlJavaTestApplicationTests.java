package com.bfhl.bfhl_java_test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BfhlJavaTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
