package com.bfhl.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Service
public class StartupService {

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

    private final String registrationNumber = "1262240300"; // your regNo here

    @PostConstruct
    public void onStartup() {
        try {
            // Step 1: Send POST to generate webhook
            String generateUrl = "https://bfhldevapigw.healthrx.co.in/hiring/generateWebhook/JAVA";

            Map<String, String> requestBody = new HashMap<>();
            requestBody.put("name", "Aayush Agrawal");
            requestBody.put("regNo", registrationNumber);
            requestBody.put("email", "aayush.agrawal@mitwpu.edu.in");

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<Map<String, String>> entity = new HttpEntity<>(requestBody, headers);

            ResponseEntity<String> response = restTemplate.postForEntity(generateUrl, entity, String.class);

            JsonNode json = objectMapper.readTree(response.getBody());
            String webhookUrl = json.get("webhook").asText();
            String accessToken = json.get("accessToken").asText();

            // Step 2: Solve SQL problem
            int lastDigit = Integer.parseInt(registrationNumber.replaceAll("[^0-9]", ""));
            int lastTwoDigits = lastDigit % 100;

            String sqlQuery;
            if (lastTwoDigits % 2 == 0) {
                sqlQuery = "SELECT E1.EMP_ID, E1.FIRST_NAME, E1.LAST_NAME, D.DEPARTMENT_NAME,
    COUNT(E2.EMP_ID) AS YOUNGER_EMPLOYEES_COUNT
FROM 
    EMPLOYEE E1
JOIN 
    DEPARTMENT D ON E1.DEPARTMENT = D.DEPARTMENT_ID
LEFT JOIN 
    EMPLOYEE E2 
    ON E1.DEPARTMENT = E2.DEPARTMENT
    AND DATE_PART('year', AGE(E2.DOB)) < DATE_PART('year', AGE(E1.DOB))
GROUP BY 
    E1.EMP_ID, E1.FIRST_NAME, E1.LAST_NAME, D.DEPARTMENT_NAME
ORDER BY 
    E1.EMP_ID DESC;
"; // solution for Question 2
            }

            // Step 3: Submit answer using JWT
            HttpHeaders authHeaders = new HttpHeaders();
            authHeaders.setContentType(MediaType.APPLICATION_JSON);
            authHeaders.setBearerAuth(accessToken);

            Map<String, String> answer = new HashMap<>();
            answer.put("finalQuery", sqlQuery);

            HttpEntity<Map<String, String>> answerEntity = new HttpEntity<>(answer, authHeaders);
            ResponseEntity<String> result = restTemplate.postForEntity(webhookUrl, answerEntity, String.class);

            System.out.println("Submission Result: " + result.getBody());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
